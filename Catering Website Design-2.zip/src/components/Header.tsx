import { useState, useEffect } from 'react';

interface HeaderProps {
  onNavigate: (section: string) => void;
  alwaysLight?: boolean;
}

export function Header({ onNavigate, alwaysLight = false }: HeaderProps) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      // Trigger shrink after scrolling past hero (typically 100-150px)
      setScrolled(window.scrollY > 100);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const isLight = alwaysLight || scrolled;

  const navLinksLeft = [
    { name: 'About', id: 'about' },
    { name: 'Services', id: 'services' },
  ];

  const navLinksRight = [
    { name: 'Gallery', id: 'gallery' },
    { name: 'Contact', id: 'contact' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ease-in-out ${
        isLight ? 'bg-[#EFE3D7]/98 backdrop-blur-md shadow-quiet' : 'bg-transparent'
      }`}
      style={{
        borderBottom: isLight ? '1px solid rgba(201, 195, 186, 0.2)' : 'none',
        // Kalm Kitchen style: Header shrinks on scroll
        height: scrolled ? '70px' : '90px',
      }}
    >
      <div className="container-wide mx-auto px-6 lg:px-8 h-full">
        {/* Desktop Layout: Left Nav | Center Logo | Right Nav + CTA */}
        <div className="hidden lg:grid lg:grid-cols-3 items-center h-full gap-8">
          {/* Left Navigation */}
          <nav className="flex items-center gap-8 justify-start">
            {navLinksLeft.map((link) => (
              <button
                key={link.id}
                onClick={() => onNavigate(link.id)}
                className={`group relative transition-all duration-300 ${
                  isLight 
                    ? 'text-[#36394C] hover:text-[#5B2E34]' 
                    : 'text-white hover:text-[#C4A46A]'
                }`}
                style={{ 
                  fontSize: '15px', 
                  fontWeight: 500,
                  fontFamily: 'Montserrat, sans-serif',
                }}
              >
                {link.name}
                {/* Brass underline on hover */}
                <span 
                  className="absolute -bottom-1 left-0 h-[1px] bg-[#C4A46A] w-0 group-hover:w-full transition-all duration-300"
                />
              </button>
            ))}
          </nav>

          {/* Centered Logo */}
          <div className="flex justify-center">
            <button
              onClick={() => {
                onNavigate('home');
                window.scrollTo(0, 0);
              }}
              className="group transition-all duration-500 ease-in-out hover:opacity-80 focus:opacity-80 focus:outline-none"
              aria-label="La Bella Mesa Home"
            >
              <div className="flex flex-col items-center">
                {/* Main Wordmark */}
                <div 
                  className={`transition-all duration-500 ease-in-out ${
                    isLight ? 'text-[#36394C]' : 'text-[#EFE3D7]'
                  }`}
                  style={{
                    fontFamily: "'Libre Baskerville', Georgia, serif",
                    fontWeight: 700,
                    fontSize: scrolled ? '18px' : '22px',
                    letterSpacing: '-0.5px',
                    lineHeight: 1.2,
                  }}
                >
                  LA BELLA MESA
                </div>
                
                {/* Brass underline on hover */}
                <div 
                  className="h-[1px] bg-[#C4A46A] w-0 group-hover:w-full transition-all duration-300 mt-1"
                />
                
                {/* Subtle tagline - only show when not scrolled */}
                <div 
                  className={`transition-all duration-500 ease-in-out overflow-hidden ${
                    isLight ? 'text-[#36394C]' : 'text-[#EFE3D7]'
                  }`}
                  style={{
                    fontFamily: "'Montserrat', sans-serif",
                    fontSize: '9px',
                    letterSpacing: '1.2px',
                    fontWeight: 400,
                    textTransform: 'uppercase',
                    opacity: scrolled ? 0 : 0.5,
                    maxHeight: scrolled ? '0px' : '20px',
                    marginTop: scrolled ? '0px' : '4px',
                  }}
                >
                  Catering & Events
                </div>
              </div>
            </button>
          </div>

          {/* Right Navigation + CTA */}
          <div className="flex items-center gap-8 justify-end">
            {navLinksRight.map((link) => (
              <button
                key={link.id}
                onClick={() => onNavigate(link.id)}
                className={`group relative transition-all duration-300 ${
                  isLight 
                    ? 'text-[#36394C] hover:text-[#5B2E34]' 
                    : 'text-white hover:text-[#C4A46A]'
                }`}
                style={{ 
                  fontSize: '15px', 
                  fontWeight: 500,
                  fontFamily: 'Montserrat, sans-serif',
                }}
              >
                {link.name}
                {/* Brass underline on hover */}
                <span 
                  className="absolute -bottom-1 left-0 h-[1px] bg-[#C4A46A] w-0 group-hover:w-full transition-all duration-300"
                />
              </button>
            ))}
            
            {/* Primary CTA - Reserved Burgundy */}
            <button
              onClick={() => onNavigate('contact')}
              className={`relative bg-[#5B2E34] text-[#EFE3D7] transition-all duration-300 hover:bg-[#4F272C] overflow-hidden group ${
                scrolled ? 'px-5 py-2.5 text-sm' : 'px-6 py-3 text-base'
              }`}
              style={{ 
                fontWeight: 500,
                letterSpacing: '0.02em',
                fontFamily: 'Montserrat, sans-serif',
              }}
            >
              <span className="relative z-10">Inquire</span>
              <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            </button>
          </div>
        </div>

        {/* Mobile Layout */}
        <div className="flex lg:hidden items-center justify-between h-full">
          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className={`p-2 transition-colors ${
              isLight ? 'text-[#36394C]' : 'text-[#EFE3D7]'
            }`}
            aria-label="Toggle menu"
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              {mobileMenuOpen ? (
                <path d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path d="M3 12h18M3 6h18M3 18h18" />
              )}
            </svg>
          </button>

          {/* Mobile Centered Logo */}
          <button
            onClick={() => {
              onNavigate('home');
              window.scrollTo(0, 0);
            }}
            className="transition-all duration-500 ease-in-out hover:opacity-80 focus:opacity-80 focus:outline-none"
            aria-label="La Bella Mesa Home"
          >
            <div 
              className={`transition-all duration-500 ease-in-out ${
                isLight ? 'text-[#36394C]' : 'text-[#EFE3D7]'
              }`}
              style={{
                fontFamily: "'Libre Baskerville', Georgia, serif",
                fontWeight: 700,
                fontSize: scrolled ? '16px' : '18px',
                letterSpacing: '-0.5px',
              }}
            >
              LA BELLA MESA
            </div>
          </button>

          {/* Mobile CTA */}
          <button
            onClick={() => onNavigate('contact')}
            className={`bg-[#5B2E34] text-[#EFE3D7] transition-all duration-300 hover:bg-[#4F272C] ${
              scrolled ? 'px-4 py-2 text-sm' : 'px-5 py-2.5 text-sm'
            }`}
            style={{ 
              fontWeight: 500,
              fontFamily: 'Montserrat, sans-serif',
            }}
          >
            Inquire
          </button>
        </div>

        {/* Mobile Menu Dropdown */}
        {mobileMenuOpen && (
          <div 
            className={`lg:hidden absolute top-full left-0 right-0 ${
              isLight ? 'bg-[#EFE3D7]' : 'bg-[#36394C]'
            } shadow-lg`}
          >
            <nav className="flex flex-col p-6 gap-4">
              {[...navLinksLeft, ...navLinksRight].map((link) => (
                <button
                  key={link.id}
                  onClick={() => {
                    onNavigate(link.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`text-left transition-colors ${
                    isLight ? 'text-[#36394C] hover:text-[#5B2E34]' : 'text-[#EFE3D7] hover:text-[#C4A46A]'
                  }`}
                  style={{ 
                    fontSize: '16px',
                    fontWeight: 500,
                    fontFamily: 'Montserrat, sans-serif',
                  }}
                >
                  {link.name}
                </button>
              ))}
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
