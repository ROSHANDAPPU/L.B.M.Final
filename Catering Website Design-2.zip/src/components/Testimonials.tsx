const testimonials = [
  {
    quote: "Every detail was handled. The cuisine was beautiful. Service was seamless.",
    author: "Sofia & Marco",
    event: "Wedding Reception",
  },
  {
    quote: "Quality is their standard. Our event ran smoothly. Clients were impressed.",
    author: "James Patterson",
    event: "Corporate Gala",
  },
  {
    quote: "First consultation to final course. Everything felt natural. Truly special.",
    author: "Elena Rodriguez",
    event: "Anniversary Dinner",
  },
];

export function Testimonials() {
  return (
    <section id="testimonials" className="section-padding bg-[#EFE3D7]">
      <div className="container-wide mx-auto px-6 lg:px-8">
        {/* Section Number - Kalm Kitchen Style */}
        <div className="section-number mb-12">
          <span className="inline-block px-3 py-1 border border-[#C4A46A]/30">03 · Testimonials</span>
        </div>

        {/* Intro */}
        <div className="max-w-3xl mb-16">
          <h2 className="text-[#36394C] mb-6">
            Client Voices
          </h2>
          <div className="h-[1px] bg-[#C4A46A] w-16 mb-6" />
          <p className="text-[#36394C]" style={{ fontSize: '17px', lineHeight: 1.7 }}>
            What our clients say.
          </p>
        </div>

        {/* Testimonials - Clean Grid */}
        <div className="grid md:grid-cols-3 gap-12 lg:gap-16">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="relative bg-white breathe shadow-quiet brass-pattern"
            >
              {/* Brass accent */}
              <div className="absolute top-0 left-0 w-full h-[1px] bg-[#C4A46A]" />
              
              {/* Quote mark - subtle */}
              <div 
                className="text-[#C4A46A] mb-4 opacity-30"
                style={{
                  fontFamily: 'Libre Baskerville, Georgia, serif',
                  fontSize: '48px',
                  lineHeight: 1,
                }}
              >
                "
              </div>

              <p 
                className="text-[#36394C] mb-6" 
                style={{ 
                  fontSize: '16px', 
                  lineHeight: 1.7,
                  fontFamily: 'Montserrat, sans-serif',
                  fontWeight: 400,
                  fontStyle: 'italic',
                }}
              >
                {testimonial.quote}
              </p>
              
              {/* Stone divider */}
              <div className="h-[1px] bg-[#C9C3BA] w-12 mb-4" />
              
              <p 
                className="text-[#5B2E34] mb-1" 
                style={{ 
                  fontWeight: 600,
                  fontSize: '15px',
                }}
              >
                {testimonial.author}
              </p>
              <p 
                className="section-number"
                style={{ fontSize: '11px' }}
              >
                {testimonial.event}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
